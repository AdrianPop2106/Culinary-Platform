create
    definer = root@localhost procedure addChefs(IN chefName varchar(20), IN pass varchar(20), IN email varchar(25),
                                                IN ordering tinyint(1))
begin
	call addUser(chefName,pass,email);
    SET @userId = (select id from users where chefName=users.UserName AND pass=users.Pass); 
	INSERT INTO `culinary`.`chefs` (`userId`, `ordering`) VALUES (@userId,ordering);
end;

