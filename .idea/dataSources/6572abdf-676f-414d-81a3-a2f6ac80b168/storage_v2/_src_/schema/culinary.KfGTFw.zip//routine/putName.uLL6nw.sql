create
    definer = root@localhost procedure putName(IN email varchar(25), IN newName varchar(20))
begin
	SET @userId=(select id from users where oldName=users.UserName AND pass=users.Pass);
    Update users SET UserName=newName where Id=@userId;
end;

