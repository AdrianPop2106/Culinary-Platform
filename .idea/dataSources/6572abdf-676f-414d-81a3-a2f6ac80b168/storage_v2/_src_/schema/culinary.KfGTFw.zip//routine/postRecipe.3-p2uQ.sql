create
    definer = root@localhost procedure postRecipe(IN chefName varchar(25), IN title varchar(20),
                                                  IN description varchar(1000))
begin
	SET @chefId=(select c.id from chefs c inner join users u on chefName=u.userName);
	INSERT INTO `culinary`.`recipe` (`chefId`, `title`, `description`) VALUES (@chefId,title,description);
end;

