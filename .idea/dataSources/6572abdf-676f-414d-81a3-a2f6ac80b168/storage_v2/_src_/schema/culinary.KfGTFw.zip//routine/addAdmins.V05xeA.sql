create
    definer = root@localhost procedure addAdmins(IN adminName varchar(20), IN pass varchar(20), IN email varchar(25))
begin
	call addUser(adminName,pass,email);
    SET @userId = (select id from users where adminName=users.UserName AND pass=users.Pass); 
	INSERT INTO `culinary`.`admins` (`userId`) VALUES (@userId);
end;

