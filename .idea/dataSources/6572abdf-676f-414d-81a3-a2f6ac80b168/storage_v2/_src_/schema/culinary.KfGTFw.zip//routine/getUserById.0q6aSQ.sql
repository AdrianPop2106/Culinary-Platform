create
    definer = root@localhost procedure getUserById(IN UserId int)
begin
	select Id as UserId,UserName
    from Users
    where UserId=Id;
end;

