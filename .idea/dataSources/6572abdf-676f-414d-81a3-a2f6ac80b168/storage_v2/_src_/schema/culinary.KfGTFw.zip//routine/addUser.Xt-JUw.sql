create
    definer = root@localhost procedure addUser(IN userName varchar(20), IN pass varchar(20), IN email varchar(25))
begin
	INSERT INTO `culinary`.`Users` (`UserName`, `Email`, `Pass`) VALUES (userName,email,pass);
end;

