create
    definer = root@localhost procedure cauta_curs(IN ID_curs int)
begin
select nume,prenume
from utilizator,profesor,curs_profesor
where utilizator.utilizator_id=profesor.ID_utilizator
and profesor.ID_profesor=curs_profesor.ID_profesor
and curs_profesor.ID_curs=ID_curs;
end;

