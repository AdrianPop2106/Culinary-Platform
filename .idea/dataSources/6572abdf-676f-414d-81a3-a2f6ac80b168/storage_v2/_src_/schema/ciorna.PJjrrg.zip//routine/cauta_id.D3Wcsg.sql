create
    definer = root@localhost procedure cauta_id(IN nume varchar(25), IN prenume varchar(25))
begin
select utilizator_id
from utilizator
where utilizator.nume=nume
and utilizator.prenume=prenume;
end;

