create definer = root@localhost trigger studenti_inscrisi
    after insert
    on inscriere_curs
    for each row
BEGIN
	IF NEW.data_renuntare is NULL THEN
	UPDATE cursuri SET numar_studenti_inscrisi = numar_studenti_inscrisi + 1 WHERE cursuri.id_curs = NEW.id_curs;
	END IF;
END;

