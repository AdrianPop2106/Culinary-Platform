create
    definer = root@localhost procedure update_nrore(IN ID_profesor int, IN numar_maxim_ore int)
begin
update profesor set numar_maxim_ore=numar_maxim_ore
where profesor.ID_profesor=ID_profesor;
end;

