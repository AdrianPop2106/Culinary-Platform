create
    definer = root@localhost procedure lista_studenti(IN nume_curs varchar(25), IN nume_profesor varchar(25),
                                                      IN prenume_profesor varchar(25))
BEGIN
  DECLARE idP,idU int;
  set idU=(select utilizator_id from utilizator where (nume=nume_profesor and prenume=prenume_profesor));
  set idP=(select id_profesor from profesor where profesor.id_utilizator=idU);

   SELECT utilizator.nume, utilizator.prenume 
	from utilizator
	inner join student on utilizator.utilizator_id=student.ID_utilizator
	inner join inscriere_curs on student.ID_student=inscriere_curs.ID_student
	inner join cursuri on inscriere_curs.ID_curs=cursuri.ID_curs
	inner join curs_profesor on cursuri.ID_curs=curs_profesor.ID_curs
	inner join profesor on curs_profesor.ID_profesor=profesor.ID_profesor
    where profesor.id_profesor=idP and cursuri.descriere=nume_curs
	order by utilizator.nume;
  END;

