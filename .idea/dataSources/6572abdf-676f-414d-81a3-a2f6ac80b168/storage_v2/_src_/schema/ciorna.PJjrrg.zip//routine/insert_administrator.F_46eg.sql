create
    definer = root@localhost procedure insert_administrator(IN ID_utilizator int, IN super_administrator tinyint(1),
                                                            IN id_super int)
begin
if true=(select super_administrator from administrator where administrator.ID_administrator=id_super)
then
insert into administrator(ID_utilizator,super_administrator) values (ID_utilizator,super_administrator);
end if;
end;

