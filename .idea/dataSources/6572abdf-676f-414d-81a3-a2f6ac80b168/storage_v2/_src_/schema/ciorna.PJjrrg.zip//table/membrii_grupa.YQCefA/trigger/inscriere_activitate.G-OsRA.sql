create definer = root@localhost trigger inscriere_activitate
    after insert
    on membrii_grupa
    for each row
BEGIN
	UPDATE activitate SET activitate.numar_studenti_inscrisi = (SELECT MAX(id_membru) from membrii_grupa where id_grupa = id_grupa);
END;

