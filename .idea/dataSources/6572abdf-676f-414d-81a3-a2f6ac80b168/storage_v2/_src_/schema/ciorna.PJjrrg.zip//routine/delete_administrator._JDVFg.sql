create
    definer = root@localhost procedure delete_administrator(IN ID_administrator int, IN Id_super int)
begin
if true=(select super_administrator from administrator where administrator.ID_administrator=Id_super)
then
delete from administrator
where administrator.ID_administrator=ID_administrator;
end if;
end;

