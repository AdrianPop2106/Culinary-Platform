create
    definer = root@localhost procedure scrie_mesaje(IN mesaj varchar(100), IN id_student int, IN nume varchar(25))
BEGIN
	SET @id_gr := NULL;
    SELECT @id_gr:=grupa_studiu.ID_grupa from grupa_studiu WHERE nume_grup = nume;
	INSERT INTO mesaje_grup (mesaj, id_student, id_grupa) VALUES (mesaj, id_student, @id_gr);
END;

