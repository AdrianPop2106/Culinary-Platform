create
    definer = root@localhost procedure update_email(IN utilizator_id int, IN email varchar(25))
begin
update utilizator set email=email
where utilizator.utilizator_id=utilizator_id;
end;

