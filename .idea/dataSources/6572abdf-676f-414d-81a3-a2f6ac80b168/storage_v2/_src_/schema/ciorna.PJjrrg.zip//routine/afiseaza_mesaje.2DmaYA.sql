create
    definer = root@localhost procedure afiseaza_mesaje(IN nume_grupa varchar(25))
BEGIN
	SELECT utilizator.nume, utilizator.prenume, mesaj FROM mesaje_grup, grupa_studiu, utilizator, student
    WHERE mesaje_grup.id_grupa = grupa_studiu.id_grupa
    AND nume_grupa = grupa_studiu.nume_grup
    and mesaje_grup.id_student = student.id_student
    and student.id_utilizator = utilizator.utilizator_id;
END;

