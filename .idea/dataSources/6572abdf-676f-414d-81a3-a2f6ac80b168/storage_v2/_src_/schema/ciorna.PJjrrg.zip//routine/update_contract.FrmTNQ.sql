create
    definer = root@localhost procedure update_contract(IN utilizator_id int, IN numar_contract varchar(25))
begin
update utilizator set numar_contract=numar_contract
where utilizator.utilizator_id=utilizator_id;
end;

