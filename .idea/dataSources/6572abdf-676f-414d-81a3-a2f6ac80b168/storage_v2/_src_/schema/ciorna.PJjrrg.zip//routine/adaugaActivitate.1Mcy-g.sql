create
    definer = root@localhost procedure adaugaActivitate(IN nume_activitate varchar(25), IN nume_profesor varchar(25),
                                                        IN prenume_profesor varchar(25), IN dataInit date,
                                                        IN dataFinal date, IN numar int, IN nume_curs varchar(25),
                                                        IN ora_i varchar(5), IN ora_s varchar(5), IN zi varchar(8))
BEGIN
  declare ID_c, ID_p, ID_u int;
  set ID_u=(select utilizator_id from utilizator where (nume=nume_profesor and prenume=prenume_profesor));
  set ID_p=(select id_profesor from profesor where profesor.id_utilizator=ID_u);
  set ID_c=(select id_curs from cursuri where descriere=nume_curs);
    insert into calendar values(NULL,ID_c,ID_p,nume_activitate,dataInit,dataFinal,numar,ora_i,ora_s,zi);
  END;

