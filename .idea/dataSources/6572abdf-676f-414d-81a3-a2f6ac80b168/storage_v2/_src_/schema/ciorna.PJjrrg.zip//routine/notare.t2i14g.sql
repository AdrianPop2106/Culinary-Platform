create
    definer = root@localhost procedure notare(IN nume varchar(25), IN prenume varchar(25), IN notaS decimal(4, 2),
                                              IN notaL decimal(4, 2), IN notaC decimal(4, 2), IN numeCurs varchar(25))
BEGIN
   	DECLARE id int;
    DECLARE idC int;
    DECLARE pS,pC,pL,idv int;
    set idC=(select id_curs from cursuri where cursuri.descriere=numeCurs);
    set pS=(SELECT pondere_seminar from ponderi_note where ID_curs=idC);
    set pC=(SELECT pondere_curs from ponderi_note where ID_curs=idC);
    set pL=(SELECT pondere_laborator from ponderi_note where ID_curs=idC);
	set id=(SELECT ID_student from student inner join utilizator on utilizator.utilizator_id=student.ID_utilizator and utilizator.nume=nume and utilizator.prenume=prenume);
	set idV=(SELECT ID_nota from note where id_student=id);
    if(idV is NULL)
		then
        insert into note values(NULL,id,idC,notaC,notaL,notaS,0.00);
        update note set medie=((nota_seminar*pS/100)+(nota_laborator*pL/100)+(nota_curs*pC/100)) where id_student=id;
	else
		update note set nota_curs=notaC, nota_laborator=notaL, nota_seminar=notaS, medie=0.00 where id_nota=idV;
		update note set medie=((nota_seminar*pS/100)+(nota_laborator*pL/100)+(nota_curs*pC/100)) where id_student=id;
	end if;
  END;

