create
    definer = root@localhost procedure vizualizare_info(IN nume varchar(25), IN CNP varchar(25))
BEGIN
	SELECT CNP as "CNP: ", nume as "Nume: ", prenume AS "Prenume: ", adresa as "Adresa: ", IBAN as "IBAN: ", numar_telefon as "Numar de telefon: ", numar_contract as "Numar contract: ", email as "Email: "
	FROM utilizator
    WHERE utilizator.CNP = CNP;
END;

