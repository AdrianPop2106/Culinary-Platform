create
    definer = root@localhost procedure update_telefon(IN utilizator_id int, IN numar_telefon varchar(25))
begin
update utilizator set numar_telefon=numar_telefon
where utilizator.utilizator_id=utilizator_id;
end;

