create
    definer = root@localhost procedure vizualizare_activitati_curente_AS_student(IN CNP varchar(25), IN stud_id int)
BEGIN
   SELECT cursuri.descriere, calendar.activitate , utilizator.nume, utilizator.prenume, calendar.zi, calendar.ora_inceput, calendar.ora_incheiere, calendar.data_inceput, calendar.data_incheiere
    from inscriere_curs
    join cursuri on inscriere_curs.id_curs = cursuri.id_curs
    join calendar on cursuri.id_curs = calendar.id_curs
    join profesor on calendar.id_profesor = profesor.id_profesor
    join utilizator on profesor.id_utilizator = utilizator.utilizator_id
    where calendar.data_inceput <= current_date and calendar.data_incheiere >= current_date
    and inscriere_curs.id_student = stud_id
    GROUP BY cursuri.descriere;
END;

