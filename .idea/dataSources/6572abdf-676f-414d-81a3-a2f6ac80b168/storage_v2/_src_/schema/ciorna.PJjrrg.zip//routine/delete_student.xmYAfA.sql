create
    definer = root@localhost procedure delete_student(IN ID_student int)
begin
delete from note 
where note.id_student=ID_student;
delete from curs_student
where curs_student.ID_student=ID_student; 
delete from student
where student.ID_student=ID_student;
end;

