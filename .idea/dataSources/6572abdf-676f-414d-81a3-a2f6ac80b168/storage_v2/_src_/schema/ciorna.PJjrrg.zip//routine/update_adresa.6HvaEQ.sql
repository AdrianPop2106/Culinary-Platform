create
    definer = root@localhost procedure update_adresa(IN utilizator_id int, IN adresa varchar(25))
begin
update utilizator set adresa=adresa
where utilizator.utilizator_id=utilizator_id;
end;

