create
    definer = root@localhost procedure filtare_studenti()
begin
select *
from utilizator,student
where utilizator_ID=ID_utilizator;
end;

