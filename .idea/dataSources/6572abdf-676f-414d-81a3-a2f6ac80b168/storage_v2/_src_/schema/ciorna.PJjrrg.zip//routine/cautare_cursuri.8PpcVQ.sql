create
    definer = root@localhost procedure cautare_cursuri()
BEGIN
	select descriere from cursuri
    group by cursuri.descriere;
end;

