create
    definer = root@localhost procedure vizualizare_activitati_zi_curenta_AS_student(IN CNP varchar(25), IN stud_id int)
BEGIN
    SELECT cursuri.descriere as 'Curs', calendar.activitate as 'Activitate', utilizator.nume as 'Nume profesor', utilizator.prenume as 'Prenume profesor', calendar.ora_inceput as 'Ora incepere', calendar.ora_incheiere as 'Ora terminare' 
    from inscriere_curs
    join cursuri on inscriere_curs.id_curs = cursuri.id_curs
    join calendar on cursuri.id_curs = calendar.id_curs
    join profesor on calendar.id_profesor = profesor.id_profesor
    join utilizator on profesor.id_utilizator = utilizator.utilizator_id
    where calendar.data_inceput < current_date and calendar.data_incheiere > current_date
    and calendar.zi = (SELECT dayname(current_date ))
    and inscriere_curs.id_student = stud_id
    GROUP BY cursuri.descriere;
END;

