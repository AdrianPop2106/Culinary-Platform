create
    definer = root@localhost procedure cauta_nume(IN nume varchar(25))
begin
select *
from utilizator
where utilizator.nume=nume;
end;

