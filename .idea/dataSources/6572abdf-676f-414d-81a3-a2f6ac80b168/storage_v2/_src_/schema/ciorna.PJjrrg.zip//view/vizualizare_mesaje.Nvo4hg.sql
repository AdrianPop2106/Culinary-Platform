create view vizualizare_mesaje as
select `ciorna`.`mesaje_grup`.`mesaj` AS `mesaj`
from `ciorna`.`mesaje_grup`;

