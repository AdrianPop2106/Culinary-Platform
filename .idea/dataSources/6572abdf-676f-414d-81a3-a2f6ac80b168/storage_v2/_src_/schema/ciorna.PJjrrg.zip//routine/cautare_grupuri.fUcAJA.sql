create
    definer = root@localhost procedure cautare_grupuri()
BEGIN
	select nume_grup from grupa_studiu;
end;

