create
    definer = root@localhost procedure parasire_grup(IN id_student int, IN nume varchar(25))
begin
	SET @id_gr := NULL;
    SELECT @id_gr:=grupa_studiu.ID_grupa from grupa_studiu WHERE nume_grup = nume;
	delete from membrii_grupa where id_student = membrii_grupa.id_student
									and @id_gr = membrii_grupa.id_grupa;
end;

