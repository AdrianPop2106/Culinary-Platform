create
    definer = root@localhost procedure update_an(IN ID_student int, IN an_studiu int)
begin
update student set an_studiu=an_studiu
where student.ID_student=ID_student;
end;

