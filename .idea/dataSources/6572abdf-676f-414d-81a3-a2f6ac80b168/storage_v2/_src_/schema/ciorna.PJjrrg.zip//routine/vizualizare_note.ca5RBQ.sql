create
    definer = root@localhost procedure vizualizare_note(IN CNP varchar(25))
BEGIN
	SELECT cursuri.descriere, note.nota_curs , note.nota_seminar, note.nota_laborator, note.medie 
	FROM utilizator
	JOIN student ON utilizator.utilizator_id = student.id_utilizator
	JOIN inscriere_curs ON student.id_student = inscriere_curs.id_student
	JOIN cursuri ON inscriere_curs.id_curs = cursuri.id_curs
	JOIN note ON cursuri.id_curs = note.id_curs
    WHERE CNP = utilizator.CNP
	GROUP BY cursuri.descriere;
END;

