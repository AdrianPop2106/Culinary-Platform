create
    definer = root@localhost procedure adaugare_activitate(IN ID_grupa int, IN denumire varchar(25),
                                                           IN data_organizare date, IN ora varchar(25),
                                                           IN numar_minim_participanti int, IN durata_expirare int)
begin
	insert into activitate (ID_grupa, denumire , data_organizare , ora , numar_minim_participanti , durata_expirare, data_creare) values (ID_grupa, denumire, data_organizare , ora , numar_minim_participanti , durata_expirare, current_timestamp());
end;

