create
    definer = root@localhost procedure viz_note(IN nume varchar(25), IN prenume varchar(25), IN numeCurs varchar(25))
BEGIN
   	DECLARE id int;
    DECLARE idC int;
    DECLARE pS,pC,pL,idv int;
    set idC=(select id_curs from cursuri where cursuri.descriere=numeCurs);
    set pS=(SELECT pondere_seminar from ponderi_note where ID_curs=idC);
    set pC=(SELECT pondere_curs from ponderi_note where ID_curs=idC);
    set pL=(SELECT pondere_laborator from ponderi_note where ID_curs=idC);
	set id=(SELECT ID_student from student inner join utilizator on utilizator.utilizator_id=student.ID_utilizator and utilizator.nume=nume and utilizator.prenume=prenume);
    SELECT nota_curs,nota_laborator, nota_seminar, medie
    from note
    where id_student=id;
  END;

