create
    definer = root@localhost procedure viz_inf_as_profesor(IN nume varchar(25), IN prenume varchar(25))
BEGIN
   SELECT *
   from utilizator
   where utilizator.nume=nume and utilizator.prenume=prenume;
  END;

