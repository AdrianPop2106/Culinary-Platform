create
    definer = root@localhost procedure inscriere_curs(IN nume varchar(25), IN id_stud int, IN nr_studenti int)
BEGIN
    SET @id_curs := NULL;
    SELECT @id_curs:=cursuri.ID_curs from cursuri WHERE descriere = nume AND cursuri.numar_studenti_inscrisi = nr_studenti;
	INSERT INTO inscriere_curs (ID_student, ID_curs, data_inscriere) VALUES (id_stud, @id_curs, CURRENT_DATE);
	INSERT INTO note(id_student, id_curs) VALUES (id_stud, @id_curs); 
END;

