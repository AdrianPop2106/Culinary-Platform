create definer = root@localhost trigger calcul_medie
    before update
    on note
    for each row
BEGIN
     set new.medie = ((select @pondere_laborator := ponderi_note.pondere_laborator from ponderi_note where ponderi_note.id_curs = new.id_curs)/100*new.nota_laborator +
		 			(select @pondere_curs := ponderi_note.pondere_curs from ponderi_note where ponderi_note.id_curs = new.id_curs)/100*new.nota_curs +
                     (select @pondere_seminar := ponderi_note.pondere_seminar from ponderi_note where ponderi_note.id_curs = new.id_curs)/100*new.nota_seminar );
END;

