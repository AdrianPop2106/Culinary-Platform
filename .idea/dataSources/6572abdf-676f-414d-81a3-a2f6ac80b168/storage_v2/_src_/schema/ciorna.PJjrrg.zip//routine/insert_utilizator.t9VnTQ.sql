create
    definer = root@localhost procedure insert_utilizator(IN CNP varchar(25), IN nume varchar(25),
                                                         IN prenume varchar(25), IN adresa varchar(25),
                                                         IN IBAN varchar(25), IN numar_telefon varchar(25),
                                                         IN numar_contract int, IN email varchar(25))
begin
insert into utilizator(CNP,nume,prenume,adresa,IBAN,numar_telefon,numar_contract,email) values (CNP,nume,prenume,adresa,IBAN,numar_telefon,numar_contract,email);
end;

