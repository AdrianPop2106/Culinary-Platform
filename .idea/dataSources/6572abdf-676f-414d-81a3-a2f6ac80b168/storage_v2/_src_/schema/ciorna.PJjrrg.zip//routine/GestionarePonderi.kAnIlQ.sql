create
    definer = root@localhost procedure GestionarePonderi(IN pLab decimal(4, 2), IN pCurs decimal(4, 2),
                                                         IN pSem decimal(4, 2), IN numeCurs varchar(25))
BEGIN
  declare id,p int;
  set id=(select id_curs from cursuri where descriere=numeCurs);
  set p=(select pondere_laborator from ponderi_note where id_curs=id);
  
  if p is null
  then 
  insert into ponderi_note values(id,pLab,pSem,pCurs);
  
  else
  update ponderi_note
  set pondere_laborator=pLab, 
  pondere_curs=pCurs,
  pondere_seminar=pSem
  where ID_curs=id;
  end if;
  END;

