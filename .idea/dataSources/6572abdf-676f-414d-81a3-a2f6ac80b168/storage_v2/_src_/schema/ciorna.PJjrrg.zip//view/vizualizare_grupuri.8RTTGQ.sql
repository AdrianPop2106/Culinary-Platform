create view vizualizare_grupuri as
select `ciorna`.`grupa_studiu`.`nume_grup` AS `nume_grup`
from `ciorna`.`grupa_studiu`
group by `ciorna`.`grupa_studiu`.`nume_grup`;

