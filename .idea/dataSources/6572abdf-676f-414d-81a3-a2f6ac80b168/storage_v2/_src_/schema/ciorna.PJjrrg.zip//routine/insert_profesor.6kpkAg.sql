create
    definer = root@localhost procedure insert_profesor(IN ID_utilizator int, IN numar_minim_ore int,
                                                       IN numar_maxim_ore int, IN departament varchar(25),
                                                       IN numar_total_studenti int)
begin
insert into profesor(ID_utilizator,numar_minim_ore,numar_maxim_ore, departament,numar_total_studenti)
values (ID_utilizator,numar_minim_ore,numar_maxim_ore, departament,numar_total_studenti);
end;

