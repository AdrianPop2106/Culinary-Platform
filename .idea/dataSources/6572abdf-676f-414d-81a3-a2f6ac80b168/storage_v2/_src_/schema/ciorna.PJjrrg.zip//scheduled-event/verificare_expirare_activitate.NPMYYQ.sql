create definer = root@localhost event verificare_expirare_activitate on schedule
    at '2021-01-04 21:11:32'
    enable
    do
    IF current_time - activitate.data_creare > activitate.durata_expirare then
      DELETE from activitate where current_time - activitate.data_creare > activitate.durata_expirare and activitate.numar_studenti_inscrisi < activitate.numar_minim_participanti;
      INSERT INTO mesaje_grup (mesaj) VALUES ("Activitate anulata");
     end IF;

