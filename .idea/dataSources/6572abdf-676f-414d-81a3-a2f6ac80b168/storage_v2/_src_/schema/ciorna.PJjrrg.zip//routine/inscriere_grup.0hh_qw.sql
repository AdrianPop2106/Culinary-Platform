create
    definer = root@localhost procedure inscriere_grup(IN nume varchar(25), IN CNP varchar(25))
BEGIN
    SET @id_gr := NULL;
    SELECT @id_gr:=grupa_studiu.ID_grupa from grupa_studiu WHERE nume_grup = nume;
    SET @id_stud := NULL;
    SELECT @id_stud:=id_student from student, utilizator WHERE student.id_utilizator = utilizator.utilizator_id and utilizator.CNP = CNP;
    insert into membrii_grupa(id_grupa, id_student) VALUES (@id_gr, @id_stud);
END;

