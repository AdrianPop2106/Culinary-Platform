create
    definer = root@localhost procedure parasire_curs(IN CNP varchar(25), IN nume_curs varchar(25))
begin
	set @id := null;
    select @id:=utilizator_id from utilizator where CNP = utilizator.CNP;
    set @id_stud := null;
    select @id_stud:=student.id_student, @id_curs:=cursuri.id_curs from student, inscriere_curs, cursuri
								where student.id_student = inscriere_curs.id_student
                                and @id = student.id_utilizator
                                and inscriere_curs.id_curs = cursuri.id_curs
                                and cursuri.descriere = nume_curs;
	delete from inscriere_curs where id_student = @id_stud and id_curs = @id_curs;
	delete from note WHERE id_curs = @id_curs and id_student = @id_stud;
    UPDATE cursuri SET numar_studenti_inscrisi = numar_studenti_inscrisi - 1 WHERE cursuri.id_curs = @id_curs;
end;

