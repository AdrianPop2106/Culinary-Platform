create
    definer = root@localhost procedure asignare_prof(IN ID_profesor int, IN ID_curs int)
begin
insert into curs_profesor values(ID_curs,ID_profesor);
end;

