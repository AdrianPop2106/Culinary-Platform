create
    definer = root@localhost procedure filtare_profesori()
begin
select *
from utilizator,profesor
where utilizator_ID=ID_utilizator;
end;

