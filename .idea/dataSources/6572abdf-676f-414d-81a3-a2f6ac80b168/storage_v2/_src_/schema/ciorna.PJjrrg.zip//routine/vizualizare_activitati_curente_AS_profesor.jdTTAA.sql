create
    definer = root@localhost procedure vizualizare_activitati_curente_AS_profesor(IN nume_profesor varchar(25), IN prenume_profesor varchar(25))
BEGIN
  declare idP,idU int;
  set idU=(select utilizator_id from utilizator where (nume=nume_profesor and prenume=prenume_profesor));
  set idP=(select id_profesor from profesor where profesor.id_utilizator=idU);
	SELECT utilizator.nume, utilizator.prenume, calendar.activitate as 'ACTIVITATI CURENTE', calendar.data_inceput as "DATA INCEPUT", calendar.ora_inceput, calendar.ora_incheiere, calendar.zi
	from utilizator
	inner join profesor on utilizator.utilizator_id=profesor.ID_utilizator
	inner join calendar on profesor.ID_profesor=calendar.ID_profesor
	where calendar.data_inceput<=current_date and calendar.data_incheiere>=current_date and profesor.id_profesor=idP;
  END;

