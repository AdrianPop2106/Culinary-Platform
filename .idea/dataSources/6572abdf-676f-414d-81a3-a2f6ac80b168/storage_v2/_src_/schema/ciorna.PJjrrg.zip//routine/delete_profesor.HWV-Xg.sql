create
    definer = root@localhost procedure delete_profesor(IN ID_profesor int)
begin
delete from calendar
where calendar.ID_profesor=ID_profesor;
delete from curs_profesor
where curs_profesor.ID_profesor=ID_profesor;
delete from profesor 
where profesor.ID_profesor=ID_profesor;
end;

