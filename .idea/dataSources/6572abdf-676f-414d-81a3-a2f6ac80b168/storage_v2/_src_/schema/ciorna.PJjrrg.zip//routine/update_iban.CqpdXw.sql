create
    definer = root@localhost procedure update_iban(IN utilizator_id int, IN IBAN varchar(25))
begin
update utilizator set IBAN=IBAN
where utilizator.utilizator_id=utilizator_id;
end;

