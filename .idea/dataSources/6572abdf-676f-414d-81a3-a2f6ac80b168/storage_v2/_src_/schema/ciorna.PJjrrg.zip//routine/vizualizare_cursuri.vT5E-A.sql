create
    definer = root@localhost procedure vizualizare_cursuri(IN n varchar(25), IN p varchar(25))
BEGIN
  select descriere from cursuri inner join curs_profesor on cursuri.ID_curs=curs_profesor.ID_curs 
  inner join profesor on curs_profesor.ID_profesor= profesor.ID_profesor 
  inner join utilizator on profesor.id_utilizator=utilizator.utilizator_id and utilizator.nume=n and utilizator.prenume=p;
  END;

