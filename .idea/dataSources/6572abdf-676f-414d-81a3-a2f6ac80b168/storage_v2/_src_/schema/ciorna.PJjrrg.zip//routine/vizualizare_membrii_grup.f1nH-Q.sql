create
    definer = root@localhost procedure vizualizare_membrii_grup(IN nume_grup varchar(25))
BEGIN 
	SELECT utilizator.nume, utilizator.prenume 
    FROM utilizator 
    INNER JOIN student ON utilizator.utilizator_id = student.id_utilizator
    INNER JOIN membrii_grupa ON membrii_grupa.id_student = student.id_student
    INNER JOIN grupa_studiu ON grupa_studiu.id_grupa = membrii_grupa.id_grupa
    WHERE grupa_studiu.nume_grup = nume_grup;
END;

