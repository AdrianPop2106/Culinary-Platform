create
    definer = root@localhost procedure determinare_id_student(IN CNP varchar(25))
BEGIN 
	SELECT @stud_id := student.id_student
	FROM utilizator, student
	where utilizator.utilizator_id = student.id_utilizator
    and CNP = utilizator.CNP;  
END;

