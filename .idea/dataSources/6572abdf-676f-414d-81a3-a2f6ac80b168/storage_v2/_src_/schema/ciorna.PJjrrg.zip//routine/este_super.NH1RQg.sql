create
    definer = root@localhost procedure este_super(IN nume varchar(25), IN prenume varchar(25))
begin
select ID_administrator
from administrator,utilizator
where utilizator_id=ID_utilizator
and utilizator.nume=nume
and utilizator.prenume=prenume
and administrator.super_administrator=true;
end;

