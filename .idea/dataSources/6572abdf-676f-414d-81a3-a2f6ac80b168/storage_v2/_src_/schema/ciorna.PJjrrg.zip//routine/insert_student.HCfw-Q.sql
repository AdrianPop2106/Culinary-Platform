create
    definer = root@localhost procedure insert_student(IN ID_utilizator int, IN an_studiu int, IN ore int)
begin
insert into student(ID_utilizator,an_studiu,ore) values (ID_utilizator,an_studiu,ore);
end;

