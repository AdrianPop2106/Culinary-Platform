create view vizualizare_note as
select `ciorna`.`utilizator`.`nume`     AS `nume`,
       `ciorna`.`utilizator`.`prenume`  AS `prenume`,
       `ciorna`.`cursuri`.`descriere`   AS `descriere`,
       `ciorna`.`note`.`nota_curs`      AS `nota_curs`,
       `ciorna`.`note`.`nota_seminar`   AS `nota_seminar`,
       `ciorna`.`note`.`nota_laborator` AS `nota_laborator`
from ((((`ciorna`.`utilizator` join `ciorna`.`student` on ((`ciorna`.`utilizator`.`utilizator_id` =
                                                            `ciorna`.`student`.`ID_utilizator`))) join `ciorna`.`inscriere_curs` on ((
        `ciorna`.`student`.`ID_student` =
        `ciorna`.`inscriere_curs`.`ID_student`))) join `ciorna`.`cursuri` on ((`ciorna`.`inscriere_curs`.`ID_curs` = `ciorna`.`cursuri`.`ID_curs`)))
         join `ciorna`.`note` on ((`ciorna`.`cursuri`.`ID_curs` = `ciorna`.`note`.`ID_curs`)))
group by `ciorna`.`utilizator`.`utilizator_id`;

